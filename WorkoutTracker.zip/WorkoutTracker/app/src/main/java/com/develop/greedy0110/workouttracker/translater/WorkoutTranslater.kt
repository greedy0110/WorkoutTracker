package com.develop.greedy0110.workouttracker.translater

import com.develop.greedy0110.workouttracker.model.workout.TypeOfExercise
import com.develop.greedy0110.workouttracker.model.workout.WorkSet
import com.develop.greedy0110.workouttracker.model.workout.Workout
import com.develop.greedy0110.workouttracker.room.workout.WorkoutEntity
import com.google.gson.Gson

class WorkoutTranslater() {
    fun entityToWorkout(e: WorkoutEntity): Workout {
        return Workout(
            TypeOfExercise(e.name, e.target),
            fromString(e.sets),
            e.memo
        )
    }

    fun workoutToEntity(w: Workout): WorkoutEntity {
        return WorkoutEntity(
            0, w.type.name, w.type.target,
            toString(w.sets),
            w.memo
        )
    }

    private fun toString(w: List<WorkSet>): String {
        return Gson().toJson(w)
    }

    private fun fromString(s: String): List<WorkSet> {
        val obj = Gson().fromJson<Array<WorkSet>>(s, Array<WorkSet>::class.java)
        return obj.toList()
    }
}