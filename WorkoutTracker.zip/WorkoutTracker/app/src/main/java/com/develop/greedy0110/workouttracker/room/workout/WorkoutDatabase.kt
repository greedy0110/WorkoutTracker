package com.develop.greedy0110.workouttracker.room.workout

import android.arch.persistence.room.Database
import android.arch.persistence.room.RoomDatabase
import com.develop.greedy0110.workouttracker.translater.WorkoutTranslater

@Database(entities = [WorkoutEntity::class], version = 1)
abstract class WorkoutDatabase : RoomDatabase() {
    abstract fun workoutDao(): WorkoutDao
    val translater = WorkoutTranslater()
}