package com.develop.greedy0110.workouttracker.data

data class TypeOfExercise(
    val name: String,
    val target: String
)